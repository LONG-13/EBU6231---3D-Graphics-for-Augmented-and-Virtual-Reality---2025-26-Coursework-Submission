#include <windows.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <map>
#include <cctype>
#include <algorithm>
#include <cmath>
#include <cassert>
#include <gdiplus.h>
#include <cstring>
#pragma comment(lib, "Gdiplus.lib")
using namespace Gdiplus;
#include <shellapi.h>
// Optional: tinygltf for loading .glb/.gltf models. Put tiny_gltf.h in project include path.
#if defined(__has_include)
#  if __has_include("tiny_gltf.h")
#    include "tiny_gltf.h"
#    define TINYGLTF_AVAILABLE 1
#  else
#    define TINYGLTF_AVAILABLE 0
#  endif
#else
#  define TINYGLTF_AVAILABLE 0
#endif

// 线性代数工具（保持原有）
struct Vec3 { float x, y, z; };
struct Mat4 { float m[16]; };
static Mat4 mat4_identity()
{
    Mat4 r; for (int i=0;i<16;i++) r.m[i]=0.0f; r.m[0]=r.m[5]=r.m[10]=r.m[15]=1.0f; return r;
}
static Mat4 mat4_mul(const Mat4 &a, const Mat4 &b)
{
    Mat4 r; for (int i=0;i<16;i++) r.m[i]=0.0f;
    for (int row=0; row<4; ++row) for (int col=0; col<4; ++col)
        for (int k=0;k<4;++k) r.m[row*4+col] += a.m[row*4+k]*b.m[k*4+col];
    return r;
}
static Mat4 mat4_translate(float x, float y, float z)
{
    Mat4 r = mat4_identity(); r.m[12]=x; r.m[13]=y; r.m[14]=z; return r;
}
static Mat4 mat4_scale(float x, float y, float z)
{
    Mat4 r = mat4_identity(); r.m[0]=x; r.m[5]=y; r.m[10]=z; return r;
}
static Mat4 mat4_rotate_x(float a)
{
    Mat4 r = mat4_identity(); float c=cosf(a), s=sinf(a); r.m[5]=c; r.m[6]=s; r.m[9]=-s; r.m[10]=c; return r;
}
static Mat4 mat4_rotate_y(float a)
{
    Mat4 r = mat4_identity(); float c=cosf(a), s=sinf(a); r.m[0]=c; r.m[2]=-s; r.m[8]=s; r.m[10]=c; return r;
}
static Mat4 mat4_rotate_z(float a)
{
    Mat4 r = mat4_identity(); float c=cosf(a), s=sinf(a); r.m[0]=c; r.m[1]=s; r.m[4]=-s; r.m[5]=c; return r;
}
static Mat4 mat4_perspective(float fov, float aspect, float zn, float zf)
{
    float f = 1.0f/tanf(fov*0.5f);
    Mat4 r; for (int i=0;i<16;i++) r.m[i]=0; r.m[0]=f/aspect; r.m[5]=f; r.m[10]=(zf+zn)/(zn-zf); r.m[11]=-1; r.m[14]=(2*zf*zn)/(zn-zf); return r;
}
static Mat4 mat4_lookat(Vec3 eye, Vec3 center, Vec3 up)
{
    Vec3 f={center.x-eye.x, center.y-eye.y, center.z-eye.z};
    float fl = sqrtf(f.x*f.x+f.y*f.y+f.z*f.z); f.x/=fl; f.y/=fl; f.z/=fl;
    Vec3 u = up; float ul = sqrtf(u.x*u.x+u.y*u.y+u.z*u.z); u.x/=ul; u.y/=ul; u.z/=ul;
    Vec3 s = { f.y*u.z - f.z*u.y, f.z*u.x - f.x*u.z, f.x*u.y - f.y*u.x };
    float sl = sqrtf(s.x*s.x+s.y*s.y+s.z*s.z); s.x/=sl; s.y/=sl; s.z/=sl;
    Vec3 uu = { s.y*f.z - s.z*f.y, s.z*f.x - s.x*f.z, s.x*f.y - s.y*f.x };
    Mat4 r = mat4_identity();
    r.m[0]=s.x; r.m[4]=s.y; r.m[8]=s.z;
    r.m[1]=uu.x; r.m[5]=uu.y; r.m[9]=uu.z;
    r.m[2]=-f.x; r.m[6]=-f.y; r.m[10]=-f.z;
    r.m[12]=-(s.x*eye.x + s.y*eye.y + s.z*eye.z);
    r.m[13]=-(uu.x*eye.x + uu.y*eye.y + uu.z*eye.z);
    r.m[14]= f.x*eye.x + f.y*eye.y + f.z*eye.z;
    return r;
}
static bool project_to_screen(const Vec3 &p, const Mat4 &view, const Mat4 &proj, int screenW, int screenH, int &outX, int &outY)
{
    Mat4 mv = mat4_mul(view, mat4_identity());
    Mat4 mvp = mat4_mul(proj, mv);
    float x = p.x, y = p.y, z = p.z, w = 1.0f;
    float rx = mvp.m[0]*x + mvp.m[4]*y + mvp.m[8]*z + mvp.m[12]*w;
    float ry = mvp.m[1]*x + mvp.m[5]*y + mvp.m[9]*z + mvp.m[13]*w;
    float rz = mvp.m[2]*x + mvp.m[6]*y + mvp.m[10]*z + mvp.m[14]*w;
    float rw = mvp.m[3]*x + mvp.m[7]*y + mvp.m[11]*z + mvp.m[15]*w;
    if (rw == 0.0f) return false;
    float ndc_x = rx / rw;
    float ndc_y = ry / rw;
    outX = (int)((ndc_x * 20.5f + 20.5f) * screenW);
    outY = (int)((-ndc_y * 20.5f + 20.5f) * screenH);
    return true;
}

// 核心数据结构（保持原有）
struct Voxel { float x,y,z; Vec3 color; };
struct Block { float x,y,z; float sx,sy,sz; Vec3 color; };
static std::vector<Voxel> personVoxels;

static std::vector<Block> personBlocks;
static std::vector<std::vector<Voxel>> personVariants;
static std::vector<int> variantWs = {18, 24, 28};
static int currentVariant = 1;
static std::vector<float> variantPx = {0.16f, 0.18f, 0.22f};
static float g_pixel_size = 0.20f;
static float g_depth_size = 0.22f;

// -------------------------- LYBJ字母优化配置 --------------------------
static float lybj_base_x = 1.0f;
static float lybj_base_y = 0.78f;
static float lybj_base_z = 1.6f;
static float lybj_bob_amp = 0.80f;    // 上下浮动幅度
static float lybj_bob_speed = 5.0f;   // 浮动速度
static float lybj_rot_speed = 1.2f;   // 旋转速度
static float lybj_scale_amp = 0.15f;  // 缩放幅度
static bool lybj_enabled = true;
static std::vector<Voxel> lybjVoxels;



// -------------------------- 人像建模优化（匹配参考图） --------------------------
// 参考图风格：卡通化、高对比度色彩、明确的身体结构
static void build_person_from_attachment()
{
    personVoxels.clear();
    personBlocks.clear();

    // 参考图像素矩阵（32列×40行，优化身体比例和细节）
    // 参考像素矩阵（宽约24列，高约36行）
    // 字符说明：
    //  'H' - 粉色帽顶
    //  'h' - 粉色帽檐
    //  'f' - 肤色（脸部/手）
    //  'G' - 眼镜/镜框（浅色）
    //  'M' - 口罩（浅蓝）
    //  'r' - 红色外套
    //  'p' - 外套口袋/暗色块
    //  'B' - 深色纽扣/装饰
    //  'P' - 裤子（黑色主色）
    //  'S' - 裤子白色条纹
    //  's' - 鞋子（深灰）
    //  'W' - 白色装饰/高光
    const char* map[] = {
        "       HHHHHHHHHHH       ",
        "      HHHHHHHHHHHHH      ",
        "     HHHHHHHHHHHHHHH     ",
        "    HHHHHHHHHHHHHHHHH    ",
        "   HHHHHHHHHHHHHHHHHHH   ",
        "  HHHHHHHHHHHHHHHHHHHHH  ",
        " hhhhhhhhhhhhhhhhhhhhhhh ",
        "      ffWWWWfWWWWff      ",
        "      ffWEEWfWEEWff      ",
        "       ffMMMMMMMff       ",
        "       fffMMMMMfff       ", 
        "  rrrrrrrrrrrrrrrrrrrrrr ",
        "  rrrrrrrrrrrrrrrrrrrrrr ",
        "  rrrrrrrrrrrrrrrrrrrrrr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr    rrrrrrrrrr    rr ",
        "  rr      S P P       rr ",
        "  rr      S P P       rr ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "          S P P          ",
        "         sssGsss         "
    };

    int rows = sizeof(map)/sizeof(map[0]);
    int cols = (int)strlen(map[0]);
    // 微调像素和深度比例以更贴合参考图
    const float base_px = 0.09f;
    const float pxX = base_px * 3.0f;  // 水平像素尺寸（微调）
    const float pxY = base_px * 7.2f;  // 垂直像素尺寸（微调）
    const float depth = 1.6f;         // 整体体素深度略增大以增强立体感
    float topY = 17.0f;                // 顶部位置微调

    // 逐像素生成体素
    for (int r=0;r<rows;++r) {
        for (int c=0;c<cols;++c) {
            char ch = map[r][c];
            if (ch == ' ' ) continue;

            // 参考图风格色彩配置（带渐变/阴影）
            Vec3 colv = {0.02f,0.02f,0.02f}; // 默认深色小块
            if (ch=='H') colv = {0.96f,0.56f,0.78f};   // 帽顶（偏浓的粉色）
            if (ch=='h') colv = {1.00f,0.68f,0.86f};   // 帽檐（偏亮的粉色）
            if (ch=='f') colv = {1.0f,0.92f,0.80f};     // 肤色（脸部/手）
            if (ch=='G') colv = {0.10f,0.10f,0.12f};    // 眼镜/镜框（深色边框）
            if (ch=='M') colv = {0.58f,0.80f,0.95f};    // 口罩（浅蓝）
            if (ch=='r') colv = {0.86f,0.12f,0.12f};    // 红色外套（主色）
            if (ch=='p') colv = {0.58f,0.14f,0.14f};    // 口袋/暗色块（更暗）
            if (ch=='B') colv = {0.12f,0.12f,0.12f};    // 深色纽扣/点缀
            if (ch=='P') colv = {0.04f,0.04f,0.04f};    // 黑色裤子
            if (ch=='S') colv = {0.98f,0.98f,0.98f};    // 裤子白条纹
            if (ch=='s') colv = {0.18f,0.16f,0.18f};    // 鞋子（深灰）

            // 计算体素位置与深度：根据行位置引入轻微 Z 偏移，增强立体感
            float cx = (c - cols/2) * pxX;
            float cy = topY - r * pxY;
            Voxel v;
            v.x = cx;
            v.y = cy;
            // 让头部/上半身稍微靠前，下半身略靠后以模拟透视
            float rowFactor = 1.0f - (float)r / (float)rows; // 1 = 顶部
            v.z = (rowFactor - 0.5f) * depth * 0.6f; // 局部 Z 偏移

            // 基于行距和横向距离额外添加微小的深度扰动，制造厚度感
            float colCenter = (float)c - (float)cols * 0.5f;
            v.z += -fabsf(colCenter) / (float)cols * 0.15f * depth;

            // 色彩亮度根据 rowFactor 做简单明暗调整（头部更亮，外套/裤子更饱和）
            float light = 0.88f + 0.22f * rowFactor; // 范围约 [0.88,1.10]
            v.color = { colv.x * light, colv.y * light, colv.z * light };
            personVoxels.push_back(v);
        }
    }

    // 优化粗粒度身体块（增强3D立体感）
    float minwx=1e9f, minwy=1e9f, maxwx=-1e9f, maxwy=-1e9f;
    for (auto &v : personVoxels) { 
        if (v.x<minwx) minwx=v.x; 
        if (v.x>maxwx) maxwx=v.x; 
        if (v.y<minwy) minwy=v.y; 
        if (v.y>maxwy) maxwy=v.y; 
    }
    float wwidth = (maxwx - minwx) > 0.1f ? (maxwx - minwx) : 0.1f;
    float wheight = (maxwy - minwy) > 0.1f ? (maxwy - minwy) : 0.1f;
    float centerX = (minwx + maxwx) * 0.5f;

    // 头部（优化比例和位置）
    Block head; 
    head.sx = wwidth * 0.5f; 
    head.sy = wheight * 0.18f; 
    head.sz = wwidth * 0.45f; 
    head.x = centerX; 
    head.y = maxwy - head.sy*0.6f; 
    head.z = 0.0f; 
    head.color = {1.0f,0.9f,0.78f};
    personBlocks.push_back(head);

    // 躯干（优化宽度和厚度）
    Block torso; 
    torso.sx = wwidth * 0.75f; 
    torso.sy = wheight * 0.45f; 
    torso.sz = wwidth * 0.5f; 
    torso.x = centerX; 
    torso.y = maxwy - head.sy - torso.sy*0.5f; 
    torso.z = 0.0f; 
    torso.color = {1.0f,0.45f,0.0f};
    personBlocks.push_back(torso);

    // 手臂（优化长度和位置）
    Block larm; 
    larm.sx = wwidth * 0.22f; 
    larm.sy = torso.sy * 0.9f; 
    larm.sz = wwidth * 0.28f; 
    larm.x = centerX - torso.sx*0.65f; 
    larm.y = torso.y; 
    larm.z = 0.0f; 
    larm.color = torso.color; 
    personBlocks.push_back(larm);
    
    Block rarm = larm; 
    rarm.x = centerX + torso.sx*0.65f; 
    personBlocks.push_back(rarm);

    // 腿部（优化粗细和颜色）
    Block lleg; 
    lleg.sx = wwidth * 0.25f; 
    lleg.sy = wheight * 0.38f; 
    lleg.sz = wwidth * 0.32f; 
    lleg.x = centerX - wwidth*0.2f; 
    lleg.y = maxwy - head.sy - torso.sy - lleg.sy*0.5f; 
    lleg.z = 0.0f; 
    lleg.color = {0.02f,0.02f,0.02f}; 
    personBlocks.push_back(lleg);
    
    Block rleg = lleg; 
    rleg.x = centerX + wwidth*0.2f; 
    rleg.color = {0.18f,0.15f,0.2f}; 
    personBlocks.push_back(rleg);
}

// -------------------------- 字母3D建模优化 --------------------------
// 扩展5x5字符集（支持LYBJ）
//
// 说明：
// - `glyph5` 定义了一个简易的 5x5 点阵字模，用字符 'X' 表示像素存在，'.' 或其他表示空白。
// - 目前仅包含大写字母的子集（L,Y,B,J），用于构建名字和标识文本的体素几何。
// - 这个点阵表用于后续的体素生成函数 `build_letter_voxels`、`build_name_voxels_from_glyphs` 等。
static const std::map<char, std::vector<std::string>> glyph5 = {
    {'L', {"X....","X....","X....","X....","XXXXX"}},
    {'Y', {"X...X","X...X","XXXXX","..X..","..X.."}},
    {'B', {"XXXX.","X...X","XXXX.","X...X","XXXX."}},
    {'J', {"....X","....X","....X","X...X","XXXXX"}}
};

// 3D字母体素生成（优化深度和立体感）
// build_letter_voxels
// 生成一个字符串的 3D 体素表示（按 5x5 点阵），并支持多层深度以增强立体感。
// 参数：
// - text: 要生成的宽字符文本（宽字节 wchar_t 被转换为 ASCII 大写来查表）。
// - outVoxels: 输出体素向量（每个体素含位置和颜色）。
// 逻辑要点：
// 1. 使用 `glyph5` 点阵表按字符逐像素生成体素。
// 2. 为增强立体感，沿 Z 方向生成多层（depthLayers），并对靠近/远离层做简单明暗处理。
// 3. 通过 psize 和 gap 控制字符像素大小与字间距，startX/startY 做整体居中对齐。
static void build_letter_voxels(const std::wstring &text, std::vector<Voxel> &outVoxels)
{
    outVoxels.clear();
    const int glyphW = 5, glyphH = 5;
    float psize = g_pixel_size * 3.0f;  // 字母像素尺寸优化（更小）
    float gap = psize * 2.2f;           // 字母间距优化（更紧凑）
    float depthLayers = 2;              // 3D深度层数（更少，更细）
    float layerDepth = g_depth_size * 0.2f; // 每层深度（更薄）

    int n = (int)text.size();
    if (n == 0) return;

    // 计算总宽度并居中起始 X/Y
    float totalW = n * glyphW * psize + (n-1) * gap;
    float startX = -totalW*0.5f + glyphW*psize*0.5f;
    float startY = glyphH*psize*0.5f;

    // 逐字母生成 3D 体素
    for (int i=0;i<n;++i) {
        char ch = (char)text[i];
        if (ch >= 'a' && ch <= 'z') ch = char(ch - 'a' + 'A');
        auto it = glyph5.find(ch);
        if (it == glyph5.end()) continue; // 未定义字符跳过
        const auto &rows = it->second;

        // 每个字符生成多层深度，外层颜色略暗以模拟阴影
        for (int layer=0; layer<depthLayers; layer++) {
            float zOffset = layer * layerDepth;
            Vec3 color = {0.12f,0.12f,0.12f}; // 基础颜色
            if (layer > 0) {
                color.x *= (1.0f - layer*0.2f);
                color.y *= (1.0f - layer*0.2f);
                color.z *= (1.0f - layer*0.2f);
            }

            for (int ry=0; ry<glyphH; ++ry) {
                const std::string &row = rows[ry];
                for (int rx=0; rx<glyphW && rx < (int)row.size(); ++rx) {
                    if (row[rx] != 'X') continue;

                    // 计算体素在世界坐标系中的位置并加入列表
                    float cx = startX + i * (glyphW*psize + gap) + (rx - glyphW*0.5f + 0.5f) * psize;
                    float cy = startY - (ry - glyphH*0.5f + 0.5f) * psize;
                    float cz = -zOffset;

                    Voxel v; v.x = cx; v.y = cy; v.z = cz; v.color = color;
                    outVoxels.push_back(v);
                }
            }
        }
    }
}

// LYBJ字母3D建模（调用优化后的生成函数）
// build_lybj_voxels
// 为固定文本 "LYBJ" 生成 3D 体素，并做居中与颜色微调。
// 说明：LYBJ 用作画面中的装饰性标题，期望为白色主体并根据 Z 深度做简单的明暗变化。
static void build_lybj_voxels()
{
    // 使用通用字母生成器生成体素
    build_letter_voxels(L"LYBJ", lybjVoxels);
    
    // 重新计算中心并平移到原点（居中），方便后续在世界空间放置
    if (!lybjVoxels.empty()) {
        float ax=0, ay=0, az=0; 
        for (const Voxel &v: lybjVoxels) { ax += v.x; ay += v.y; az += v.z; }
        ax /= (float)lybjVoxels.size(); ay /= (float)lybjVoxels.size(); az /= (float)lybjVoxels.size();
        for (Voxel &v: lybjVoxels) { v.x -= ax; v.y -= ay; v.z -= az; }

        // 颜色：白色为主，依据 z 值稍微调整明度以模拟深度阴影
        for (Voxel &v: lybjVoxels) {
            float depthFactor = 1.0f + (v.z * 0.8f);
            v.color = { 1.0f * depthFactor, 1.0f * depthFactor, 1.0f * depthFactor };
        }
    }
}



// -------------------------- 原有工具函数（保持不变） --------------------------
static bool load_person_image_and_build_voxels(const wchar_t* path, int targetW=200)
{
    Bitmap* bmp = Bitmap::FromFile(path);
    if (!bmp) return false;
    Status st = bmp->GetLastStatus(); if (st != Ok) { delete bmp; return false; }
    int w = bmp->GetWidth(), h = bmp->GetHeight();
    int gridW = targetW;
    int gridH = (int)((float)h/(float)w * gridW);
    if (gridH <= 0) gridH = gridW;
    personVoxels.clear();
    for (int gy=0; gy<gridH; ++gy) {
        for (int gx=0; gx<gridW; ++gx) {
            int sx0 = (int)( (float)gx * w / gridW );
            int sy0 = (int)( (float)gy * h / gridH );
            int sx1 = (int)( (float)(gx+1) * w / gridW );
            int sy1 = (int)( (float)(gy+1) * h / gridH );
            if (sx1<=sx0) sx1 = sx0+1; if (sy1<=sy0) sy1 = sy0+1;
            long sumR=0,sumG=0,sumB=0,count=0;
            for (int yy=sy0; yy<sy1; ++yy) for (int xx=sx0; xx<sx1; ++xx) {
                Color c; bmp->GetPixel(xx, yy, &c);
                sumR += c.GetR(); sumG += c.GetG(); sumB += c.GetB(); ++count;
            }
            if (count==0) continue;
            unsigned char r = (unsigned char)(sumR/count), g=(unsigned char)(sumG/count), b=(unsigned char)(sumB/count);
            if (r>245 && g>245 && b>245) continue;
            float px = ((float)gx - gridW*0.5f) * 0.12f;
            float py = (gridH*0.5f - (float)gy) * 0.12f + 1.6f;
            float pz = 0.0f;
            Voxel v; v.x = px; v.y = py; v.z = pz; v.color = { r/255.0f, g/255.0f, b/255.0f };
            personVoxels.push_back(v);
        }
    }
    delete bmp; return true;
}

static bool build_person_model_from_image(const wchar_t* path, int targetW=28)
{
    Bitmap* bmp = Bitmap::FromFile(path);
    if (!bmp) return false;
    Status st = bmp->GetLastStatus(); if (st != Ok) { delete bmp; return false; }
    int w = bmp->GetWidth(), h = bmp->GetHeight();
    auto samplePixelSafe = [&](int x,int y){ Color c; int sx = x; if (sx < 0) sx = 0; if (sx > w-1) sx = w-1; int sy = y; if (sy < 0) sy = 0; if (sy > h-1) sy = h-1; bmp->GetPixel(sx, sy, &c); return c; };
    Color c1 = samplePixelSafe(2,2), c2 = samplePixelSafe(w-3,2), c3 = samplePixelSafe(2,h-3), c4 = samplePixelSafe(w-3,h-3);
    int bgR = (c1.GetR()+c2.GetR()+c3.GetR()+c4.GetR())/4;
    int bgG = (c1.GetG()+c2.GetG()+c3.GetG()+c4.GetG())/4;
    int bgB = (c1.GetB()+c2.GetB()+c3.GetB()+c4.GetB())/4;
    std::vector<unsigned char> mask(w*h); int minx=w, miny=h, maxx=0, maxy=0; int totalMask=0;
    for (int y=0;y<h;++y) for (int x=0;x<w;++x) {
        Color c; bmp->GetPixel(x,y,&c);
        int dr = (int)c.GetR() - bgR; int dg = (int)c.GetG() - bgG; int db = (int)c.GetB() - bgB;
        int dist = abs(dr) + abs(dg) + abs(db);
        bool fg = (dist > 60) || ((c.GetR()+c.GetG()+c.GetB()) < 200);
        mask[y*w + x] = fg ? 1 : 0;
        if (fg) { totalMask++; if (x<minx) minx=x; if (y<miny) miny=y; if (x>maxx) maxx=x; if (y>maxy) maxy=y; }
    }
    if (totalMask < 50) { delete bmp; return false; }
    minx = (minx-2 > 0) ? (minx-2) : 0;
    miny = (miny-2 > 0) ? (miny-2) : 0;
    maxx = (maxx+2 < w-1) ? (maxx+2) : (w-1);
    maxy = (maxy+2 < h-1) ? (maxy+2) : (h-1);
    int cropW = maxx - minx + 1; int cropH = maxy - miny + 1;
    int gridW = targetW;
    int calcH = (int)((float)cropH / (float)cropW * gridW + 0.5f);
    int gridH = calcH > 4 ? calcH : 4;
    float worldTopY = 2.6f;
    float worldScaleX = 0.12f;
    for (int gy=0; gy<gridH; ++gy) {
        for (int gx=0; gx<gridW; ++gx) {
            int sx0 = minx + (int)((float)gx * cropW / gridW);
            int sy0 = miny + (int)((float)gy * cropH / gridH);
            int sx1 = minx + (int)((float)(gx+1) * cropW / gridW);
            int sy1 = miny + (int)((float)(gy+1) * cropH / gridH);
            if (sx1<=sx0) sx1 = sx0+1; if (sy1<=sy0) sy1 = sy0+1;
            int count=0; long sumR=0,sumG=0,sumB=0; int maskCount=0;
            for (int yy=sy0; yy<sy1; ++yy) for (int xx=sx0; xx<sx1; ++xx) {
                int idx = yy*w + xx; if (mask[idx]) { maskCount++; Color c; bmp->GetPixel(xx,yy,&c); sumR+=c.GetR(); sumG+=c.GetG(); sumB+=c.GetB(); }
                ++count;
            }
            if (maskCount * 3 < count) continue;
            unsigned char r = (unsigned char)(sumR / maskCount);
            unsigned char g = (unsigned char)(sumG / maskCount);
            unsigned char b = (unsigned char)(sumB / maskCount);
            float px = ((float)gx - gridW*0.5f) * worldScaleX;
            float py = worldTopY - (float)gy * worldScaleX * ((float)gridH/(float)gridW);
            Voxel v; v.x = px; v.y = py; v.z = 0.0f; v.color = { r/255.0f, g/255.0f, b/255.0f };
            personVoxels.push_back(v);
        }
    }
    float minwx=1e9f, minwy=1e9f, maxwx=-1e9f, maxwy=-1e9f;
    for (auto &v : personVoxels) { if (v.x<minwx) minwx=v.x; if (v.x>maxwx) maxwx=v.x; if (v.y<minwy) minwy=v.y; if (v.y>maxwy) maxwy=v.y; }
    float wwidth = (maxwx - minwx) > 0.1f ? (maxwx - minwx) : 0.1f;
    float wheight = (maxwy - minwy) > 0.1f ? (maxwy - minwy) : 0.1f;
    float centerX = (minwx + maxwx) * 0.5f;
    float headH = wheight * 0.15f; float torsoH = wheight * 0.40f; float pelvisH = wheight * 0.10f; float legsH = wheight * 0.35f;
    float topY = maxwy;
    Block head; head.sx = wwidth * 0.45f; head.sy = headH; head.sz = wwidth * 0.4f; head.x = centerX; head.y = topY - headH*0.5f; head.z = 0.0f; head.color = {1.0f,0.9f,0.78f};
    personBlocks.push_back(head);
    Block torso; torso.sx = wwidth * 0.7f; torso.sy = torsoH; torso.sz = wwidth * 0.45f; torso.x = centerX; torso.y = topY - headH - torsoH*0.5f; torso.z = 0.0f; torso.color = {1.0f,0.45f,0.0f};
    personBlocks.push_back(torso);
    Block larm; larm.sx = wwidth * 0.2f; larm.sy = torsoH; larm.sz = wwidth * 0.25f; larm.x = centerX - torso.sx*0.6f; larm.y = torso.y; larm.z = 0.0f; larm.color = torso.color; personBlocks.push_back(larm);
    Block rarm = larm; rarm.x = centerX + torso.sx*0.6f; personBlocks.push_back(rarm);
    Block lleg; lleg.sx = wwidth * 0.22f; lleg.sy = legsH; lleg.sz = wwidth * 0.3f; lleg.x = centerX - wwidth*0.18f; lleg.y = topY - headH - torsoH - pelvisH - legsH*0.5f; lleg.z = 0.0f; lleg.color = {0.08f,0.08f,0.08f}; personBlocks.push_back(lleg);
    Block rleg = lleg; rleg.x = centerX + wwidth*0.18f; rleg.color = {0.16f,0.12f,0.16f}; personBlocks.push_back(rleg);
    delete bmp;
    return true;
}





// 全局交互变量（保持原有）
static bool menu_open = false;
static double mouse_x=0, mouse_y=0;
static double menu_pos_x = 0.0, menu_pos_y = 0.0;

// 鼠标拖拽控制变量
static bool is_dragging = false;
static double last_mouse_x = 0.0;
static double last_mouse_y = 0.0;
static float cam_yaw = 0.0f;   // 相机绕Y轴旋转角度
static float cam_pitch = 0.0f; // 相机绕X轴旋转角度
static float fov = 45.0f;      // 视野大小（度）

static Mat4 g_view = mat4_identity();
static Mat4 g_proj = mat4_identity();
static int g_fbW = 800, g_fbH = 600;




// 前向声明：在回调中使用，但定义在文件后面
static void screen_point_to_ray(int sx, int sy, const Mat4 &view, const Mat4 &proj, int screenW, int screenH, Vec3 &outOrigin, Vec3 &outDir);
static bool ray_plane_intersect(const Vec3 &ro, const Vec3 &rd, const Vec3 &planeP, const Vec3 &planeN, Vec3 &outP);
static void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

// 文本纹理（保持原有）
struct TextTex { GLuint tex=0; int w=0,h=0; };

static GLuint create_text_texture_w(const std::wstring &text, int &out_w, int &out_h, const wchar_t* fontName=L"Microsoft YaHei", int fontSize=24)
{
    HDC hdc = CreateCompatibleDC(NULL);
    HFONT hFont = CreateFontW(-fontSize, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                              DEFAULT_PITCH | FF_DONTCARE, fontName);
    HGDIOBJ oldf = SelectObject(hdc, hFont);
    SIZE size; GetTextExtentPoint32W(hdc, text.c_str(), (int)text.size(), &size);
    int w = size.cx + 8; int h = size.cy + 8; out_w = w; out_h = h;
    BITMAPINFO bmi; ZeroMemory(&bmi, sizeof(bmi)); bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w; bmi.bmiHeader.biHeight = -h; bmi.bmiHeader.biPlanes = 1; bmi.bmiHeader.biBitCount = 32; bmi.bmiHeader.biCompression = BI_RGB;
    void* bits = NULL; HBITMAP hBmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, &bits, NULL, 0);
    HGDIOBJ oldBmp = SelectObject(hdc, hBmp);
    memset(bits, 0, w*h*4);
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(0,0,0));
    RECT rc = {4,4,w-4,h-4};
    DrawTextW(hdc, text.c_str(), (int)text.size(), &rc, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
    GLuint tex; glGenTextures(1, &tex); glBindTexture(GL_TEXTURE_2D, tex);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_BGRA, GL_UNSIGNED_BYTE, bits);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    SelectObject(hdc, oldBmp); DeleteObject(hBmp);
    SelectObject(hdc, oldf); DeleteObject(hFont);
    DeleteDC(hdc);
    return tex;
}

// Shader和渲染资源（保持原有）
static GLuint create_shader(GLenum type, const char* src)
{
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, NULL);
    glCompileShader(s);
    int ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok); if (!ok) { char buf[512]; glGetShaderInfoLog(s,512,NULL,buf); std::cout<<"Shader compile error: "<<buf<<"\n"; }
    return s;
}

static float cube_vertices[] = {
    -0.5f,-0.5f,-0.5f,  0.0f,0.0f,-1.0f,
     0.5f, 0.5f,-0.5f,  0.0f,0.0f,-1.0f,
     0.5f,-0.5f,-0.5f,  0.0f,0.0f,-1.0f,
     0.5f, 0.5f,-0.5f,  0.0f,0.0f,-1.0f,
    -0.5f,-0.5f,-0.5f,  0.0f,0.0f,-1.0f,
    -0.5f, 0.5f,-0.5f,  0.0f,0.0f,-1.0f,
    -0.5f,-0.5f, 0.5f,  0.0f,0.0f,1.0f,
     0.5f,-0.5f, 0.5f,  0.0f,0.0f,1.0f,
     0.5f, 0.5f, 0.5f,  0.0f,0.0f,1.0f,
     0.5f, 0.5f, 0.5f,  0.0f,0.0f,1.0f,
    -0.5f, 0.5f, 0.5f,  0.0f,0.0f,1.0f,
    -0.5f,-0.5f, 0.5f,  0.0f,0.0f,1.0f,
    -0.5f, 0.5f, 0.5f, -1.0f,0.0f,0.0f,
    -0.5f, 0.5f,-0.5f, -1.0f,0.0f,0.0f,
    -0.5f,-0.5f,-0.5f, -1.0f,0.0f,0.0f,
    -0.5f,-0.5f,-0.5f, -1.0f,0.0f,0.0f,
    -0.5f,-0.5f, 0.5f, -1.0f,0.0f,0.0f,
    -0.5f, 0.5f, 0.5f, -1.0f,0.0f,0.0f,
     0.5f, 0.5f, 0.5f, 1.0f,0.0f,0.0f,
     0.5f,-0.5f,-0.5f, 1.0f,0.0f,0.0f,
     0.5f, 0.5f,-0.5f, 1.0f,0.0f,0.0f,
     0.5f,-0.5f,-0.5f, 1.0f,0.0f,0.0f,
     0.5f, 0.5f, 0.5f, 1.0f,0.0f,0.0f,
     0.5f,-0.5f, 0.5f, 1.0f,0.0f,0.0f,
    -0.5f,-0.5f,-0.5f, 0.0f,-1.0f,0.0f,
     0.5f,-0.5f,-0.5f, 0.0f,-1.0f,0.0f,
     0.5f,-0.5f, 0.5f, 0.0f,-1.0f,0.0f,
     0.5f,-0.5f, 0.5f, 0.0f,-1.0f,0.0f,
    -0.5f,-0.5f, 0.5f, 0.0f,-1.0f,0.0f,
    -0.5f,-0.5f,-0.5f, 0.0f,-1.0f,0.0f,
    -0.5f, 0.5f,-0.5f, 0.0f,1.0f,0.0f,
     0.5f, 0.5f, 0.5f, 0.0f,1.0f,0.0f,
     0.5f, 0.5f,-0.5f, 0.0f,1.0f,0.0f,
     0.5f, 0.5f, 0.5f, 0.0f,1.0f,0.0f,
    -0.5f, 0.5f,-0.5f, 0.0f,1.0f,0.0f,
    -0.5f, 0.5f, 0.5f, 0.0f,1.0f,0.0f
};

static const char* vertex_src = R"(
#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
uniform mat4 model;
uniform mat4 view;
uniform mat4 proj;
out vec3 Normal;
out vec3 FragPos;
void main(){ FragPos = vec3(model * vec4(aPos,1.0)); Normal = mat3(transpose(inverse(model))) * aNormal; gl_Position = proj * view * model * vec4(aPos,1.0); }
)";

static const char* fragment_src = R"(
#version 330 core
out vec4 FragColor;
in vec3 Normal; in vec3 FragPos;
uniform vec3 color;
uniform vec3 lightDir;
void main(){ float diff = max(dot(normalize(Normal), normalize(-lightDir)), 0.1); vec3 col = color * (0.3 + 0.7*diff); FragColor = vec4(col,1.0); }
)";

static const char* v2_src = R"(#version 330 core
layout(location=0) in vec2 aPos;
uniform mat4 ortho;
void main(){ gl_Position = ortho * vec4(aPos,0.0,1.0); }
)";

static const char* f2_src = R"(#version 330 core
out vec4 FragColor; uniform vec3 color; void main(){ FragColor = vec4(color,1.0); })";

static const char* v_tex_src = R"(#version 330 core
layout(location=0) in vec2 aPos; layout(location=1) in vec2 aUV;
uniform vec2 uScreen;
out vec2 vUV;
void main(){ vec2 ndc = vec2(aPos.x / uScreen.x * 2.0 - 1.0, 1.0 - aPos.y / uScreen.y * 2.0); gl_Position = vec4(ndc, 0.0, 1.0); vUV = aUV; }
)";

static const char* f_tex_src = R"(#version 330 core
in vec2 vUV; out vec4 FragColor; uniform sampler2D tex; uniform vec3 tint; void main(){ vec4 c = texture(tex, vUV); FragColor = vec4(c.bgr, c.a) * vec4(tint,1.0); }
)";

// OpenGL对象（保持原有）
static GLuint cubeVAO=0, cubeVBO=0, prog=0, prog2=0, rectVAO=0, rectVBO=0;
static GLuint texProg=0, texVAO=0, texVBO=0;
static GLuint whiteTex=0;

static void init_gl_resources()
{
    glGenVertexArrays(1,&cubeVAO); glGenBuffers(1,&cubeVBO);
    glBindVertexArray(cubeVAO);
    glBindBuffer(GL_ARRAY_BUFFER,cubeVBO); glBufferData(GL_ARRAY_BUFFER,sizeof(cube_vertices),cube_vertices,GL_STATIC_DRAW);
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)0); glEnableVertexAttribArray(0);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)(3*sizeof(float))); glEnableVertexAttribArray(1);
    GLuint vs = create_shader(GL_VERTEX_SHADER, vertex_src);
    GLuint fs = create_shader(GL_FRAGMENT_SHADER, fragment_src);
    prog = glCreateProgram(); glAttachShader(prog,vs); glAttachShader(prog,fs); glLinkProgram(prog);
    GLuint vs2 = create_shader(GL_VERTEX_SHADER, v2_src);
    GLuint fs2 = create_shader(GL_FRAGMENT_SHADER, f2_src);
    prog2 = glCreateProgram(); glAttachShader(prog2,vs2); glAttachShader(prog2,fs2); glLinkProgram(prog2);
    GLuint vts = create_shader(GL_VERTEX_SHADER, v_tex_src);
    GLuint fts = create_shader(GL_FRAGMENT_SHADER, f_tex_src);
    texProg = glCreateProgram(); glAttachShader(texProg, vts); glAttachShader(texProg, fts); glLinkProgram(texProg);
    float quadVerts[24] = { 0,0, 0,0,  0,0, 0,1,  0,0, 1,1,  0,0, 0,0,  0,0, 1,1,  0,0, 1,0 };
    glGenVertexArrays(1,&texVAO); glGenBuffers(1,&texVBO);
    glBindVertexArray(texVAO); glBindBuffer(GL_ARRAY_BUFFER, texVBO); glBufferData(GL_ARRAY_BUFFER, sizeof(quadVerts), quadVerts, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,4*sizeof(float),(void*)0); glEnableVertexAttribArray(0);
    glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,4*sizeof(float),(void*)(2*sizeof(float))); glEnableVertexAttribArray(1);
    unsigned char whitePixel[4] = { 255,255,255,255 };
    glGenTextures(1, &whiteTex); glBindTexture(GL_TEXTURE_2D, whiteTex);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,whitePixel);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    float rect_verts[12] = { -0.3f,0.2f,  0.3f,0.2f,  0.3f,-0.2f,  -0.3f,0.2f,  0.3f,-0.2f,  -0.3f,-0.2f };
    glGenVertexArrays(1,&rectVAO); glGenBuffers(1,&rectVBO);
    glBindVertexArray(rectVAO); glBindBuffer(GL_ARRAY_BUFFER, rectVBO); glBufferData(GL_ARRAY_BUFFER,sizeof(rect_verts),rect_verts,GL_STATIC_DRAW);
    glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,2*sizeof(float),(void*)0); glEnableVertexAttribArray(0);
}

static void set_uniform_mat4(GLuint program, const char* name, const Mat4 &m)
{
    GLint loc = glGetUniformLocation(program, name);
    if (loc>=0) glUniformMatrix4fv(loc,1,GL_FALSE,m.m);
}

static void draw_cube(const Mat4 &model, const Vec3 &color, const Mat4 &view, const Mat4 &proj)
{
    glUseProgram(prog);
    set_uniform_mat4(prog, "model", model);
    set_uniform_mat4(prog, "view", view);
    set_uniform_mat4(prog, "proj", proj);
    GLint loc = glGetUniformLocation(prog, "color"); if (loc>=0) glUniform3f(loc, color.x, color.y, color.z);
    GLint ldir = glGetUniformLocation(prog, "lightDir"); if (ldir>=0) glUniform3f(ldir, -0.3f, -1.0f, -0.5f);
    glBindVertexArray(cubeVAO);
    glDrawArrays(GL_TRIANGLES, 0, 36);
}

static void draw_block(float tx,float ty,float tz,float sx,float sy,float sz, Vec3 color, const Mat4 &view, const Mat4 &proj)
{
    Mat4 m = mat4_mul(mat4_translate(tx,ty,tz), mat4_scale(sx,sy,sz));
    draw_cube(m, color, view, proj);
}

// -------------------------- 优化后的3D字母绘制函数 --------------------------
// 带旋转和缩放的字母绘制（用于LYBJ）
static void draw_letter_with_anim(const std::vector<Voxel> &voxels, float baseX, float baseY, float baseZ, 
                                  float bobAmp, float bobSpeed, float rotSpeed, float scaleAmp, 
                                  const Mat4 &view, const Mat4 &proj)
{
    float t = (float)glfwGetTime();
    float bob = sinf(t * bobSpeed) * bobAmp;
    float rotY = sinf(t * rotSpeed * 0.5f) * 0.3f; // Y轴旋转
    float scale = 1.0f + sinf(t * rotSpeed) * scaleAmp; // 呼吸缩放

    for (const Voxel &v : voxels) {
        // 构建动画模型矩阵：平移→旋转→缩放
        Mat4 translate = mat4_translate(baseX + v.x, baseY + v.y + bob, baseZ + v.z);
        Mat4 rotate = mat4_rotate_y(rotY);
        Mat4 scaleMat = mat4_scale(scale, scale, scale);
        Mat4 model = mat4_mul(translate, mat4_mul(rotate, scaleMat));

        // 绘制3D体素块
        glUseProgram(prog);
        set_uniform_mat4(prog, "model", model);
        set_uniform_mat4(prog, "view", view);
        set_uniform_mat4(prog, "proj", proj);
        GLint loc = glGetUniformLocation(prog, "color"); 
        if (loc>=0) glUniform3f(loc, v.color.x, v.color.y, v.color.z);
        GLint ldir = glGetUniformLocation(prog, "lightDir"); 
        if (ldir>=0) glUniform3f(ldir, -0.3f, -1.0f, -0.5f);
        glBindVertexArray(cubeVAO);
        glDrawArrays(GL_TRIANGLES, 0, 36);
    }
}



// -------------------------- 优化后的人像绘制（保持原有动画逻辑） --------------------------
static void draw_humanoid(float t, int action, const Mat4 &view, const Mat4 &proj)
{
    // 静态姿势：删除所有动作逻辑，保持人物静止
    float leftLeg=0, rightLeg=0, leftArm=0, rightArm=0;

    Vec3 orange={1.0f,0.45f,0.0f}; Vec3 skin={1.0f,0.93f,0.78f}; Vec3 gray={0.75f,0.75f,0.75f};
    Vec3 pink1={1.0f,0.6f,0.75f}; Vec3 pink2={0.8f,0.45f,0.55f}; Vec3 black={0.02f,0.02f,0.02f}; Vec3 yellow={1.0f,0.85f,0.1f};

    float minx=1e9f, miny=1e9f, minz=1e9f, maxx=-1e9f, maxy=-1e9f, maxz=-1e9f;
    if (!personVoxels.empty()) {
        for (const Voxel &v : personVoxels) {
            if (v.x < minx) minx = v.x; if (v.y < miny) miny = v.y; if (v.z < minz) minz = v.z;
            if (v.x > maxx) maxx = v.x; if (v.y > maxy) maxy = v.y; if (v.z > maxz) maxz = v.z;
        }
    } else {
        minx = -1.0f; maxx = 1.0f; miny = -0.6f; maxy = 2.6f; minz = -0.3f; maxz = 0.6f;
    }
    float torsoCenterX = (minx + maxx) * 0.5f;
    float torsoTopY = maxy;
    float torsoBottomY = miny + 0.4f;
    float torsoWidth = (maxx - minx);
    if (torsoWidth < 0.6f) torsoWidth = 0.6f;

    float shoulderY = torsoTopY - 0.12f;
    float shoulderOffsetX = torsoWidth * 0.5f + 0.25f;
    float hipY = torsoBottomY - 0.05f;
    float hipOffsetX = torsoWidth * 0.25f + 0.25f;

    // 绘制优化后的体素人像
    if (!personVoxels.empty()) {
        const float px = g_pixel_size; const float depth = g_depth_size;
        for (const Voxel &v : personVoxels) {
            draw_block(v.x, v.y, v.z + depth*0.5f, px, px, depth, v.color, view, proj);
            draw_block(v.x, v.y, v.z - depth*0.5f, px, px, depth, v.color, view, proj);
        }
        // 绘制优化后的粗粒度身体块
        for (const Block &b : personBlocks) {
            draw_block(b.x, b.y, b.z, b.sx, b.sy, b.sz, b.color, view, proj);
        }
    } else {
        build_person_from_attachment();
        const float px = 0.20f;
        const float depth = 0.30f;
        const char *mapRows[] = {
            "      ooooo       ",
            "     ooooooo      ",
            "    ooossssoo     ",
            "   ooossssssoo    ",
            "   oosssssss      "
};
        int rows = sizeof(mapRows)/sizeof(mapRows[0]);
        int cols = (int)strlen(mapRows[0]);
        float topY = 12.6f;
        for (int r=0;r<rows;++r) {
            //此处保存修改
            for (int c=0;c<cols;++c) {
                char ch = mapRows[r][c];
                if (ch==' ') continue;
                Vec3 colv = orange;
                if (ch=='p') colv = pink1;
                else if (ch=='s') colv = skin;
                else if (ch=='o') colv = orange;
                else if (ch=='y') colv = yellow;
                else if (ch=='g') colv = gray;
                else if (ch=='b') colv = black;
                float cx = (c - cols/2) * px;
                float cy = topY - r * px;
                draw_block(cx, cy, depth*0.5f, px, px, depth, colv, view, proj);
            }
        }
    }

    // 手臂动画（保持原有逻辑）
    Mat4 shoulder = mat4_translate(torsoCenterX - shoulderOffsetX, shoulderY, 0.0f);
    Mat4 rotLA = mat4_rotate_z(leftArm);
    Mat4 leftArmModel = mat4_mul(shoulder, mat4_mul(rotLA, mat4_translate(0.0f,-0.5f,0.0f)));
    Mat4 leftArmFinal = mat4_mul(leftArmModel, mat4_scale(0.22f,0.9f,0.3f));
    draw_cube(leftArmFinal, orange, view, proj);

    Mat4 shoulderR = mat4_translate(torsoCenterX + shoulderOffsetX, shoulderY, 0.0f);
    Mat4 rotRA = mat4_rotate_z(rightArm);
    Mat4 rightArmModel = mat4_mul(shoulderR, mat4_mul(rotRA, mat4_translate(0.0f,-0.5f,0.0f)));
    Mat4 rightArmFinal = mat4_mul(rightArmModel, mat4_scale(0.22f,0.9f,0.3f));
    draw_cube(rightArmFinal, orange, view, proj);

    // 腿部动画（保持原有逻辑）
    Mat4 leftHip = mat4_translate(torsoCenterX - hipOffsetX, hipY, 0.0f);
    Mat4 rightHip = mat4_translate(torsoCenterX + hipOffsetX, hipY, 0.0f);
    Mat4 lm = mat4_mul(leftHip, mat4_mul(mat4_rotate_x(leftLeg), mat4_scale(0.28f,1.05f,0.35f)));
    Mat4 rm = mat4_mul(rightHip, mat4_mul(mat4_rotate_x(rightLeg), mat4_scale(0.28f,1.05f,0.35f)));
    draw_cube(mat4_mul(lm, mat4_translate(0.0f,-0.5f,0.0f)), black, view, proj);
    draw_cube(mat4_mul(rm, mat4_translate(0.0f,-0.5f,0.0f)), {0.15f,0.12f,0.15f}, view, proj);

    // 鞋子（保持原有逻辑）
    float shoeXLeft = torsoCenterX - hipOffsetX;
    float shoeXRight = torsoCenterX + hipOffsetX;
    float shoeY = hipY - 0.35f;
    draw_block(shoeXLeft, shoeY, 0.05f, 0.34f,0.12f,0.4f, {0.45f,0.4f,0.4f}, view, proj);
    draw_block(shoeXRight, shoeY, 0.05f, 0.34f,0.12f,0.4f, {0.95f,0.9f,0.95f}, view, proj);
}

// -------------------------- 原有交互回调（保持不变） --------------------------
static int overlay_click_x = -1, overlay_click_y = -1;
static int check_menu_click(int winW,int winH)
{
    if (!menu_open) return -1;
    float nx = (float)(overlay_click_x)/winW*2.0f - 1.0f;
    float ny = 1.0f - (float)(overlay_click_y)/winH*2.0f;
    if (nx < -0.3f || nx > 0.3f || ny < -0.2f || ny > 0.2f) return -1;
    float relY = (ny - (-0.2f)) / (0.4f);
    int idx = 2 - (int)(relY*3.0f); if (idx<0) idx=0; if (idx>2) idx=2; return idx;
}

static void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
    if (button==GLFW_MOUSE_BUTTON_RIGHT && action==GLFW_PRESS) {
        menu_open = !menu_open;
        if (menu_open) { menu_pos_x = mouse_x; menu_pos_y = mouse_y; }
    }
    if (button==GLFW_MOUSE_BUTTON_LEFT && action==GLFW_PRESS) {
        if (menu_open) {
            // 点击任何位置都关闭菜单，不再选择动作
            menu_open = false;
        } else {
            // 开始拖拽
            is_dragging = true;
            last_mouse_x = mouse_x;
            last_mouse_y = mouse_y;
        }
    }
    if (button==GLFW_MOUSE_BUTTON_LEFT && action==GLFW_RELEASE) {
        // 结束拖拽
        is_dragging = false;
    }
}

static void cursor_pos_callback(GLFWwindow* window, double xpos, double ypos)
{
    double prev_x = mouse_x;
    double prev_y = mouse_y;
    mouse_x = xpos;
    mouse_y = ypos;

    // 处理鼠标拖拽
    if (is_dragging && !menu_open) {
        // 计算鼠标移动距离
        double delta_x = xpos - prev_x;
        double delta_y = ypos - prev_y;

        // 更新相机角度（灵敏度调整）
        cam_yaw += (float)delta_x * 0.005f;
        cam_pitch += (float)delta_y * 0.005f;

        // 限制相机俯仰角度，避免过度旋转
        const float max_pitch = (float)(3.1415926f / 2.0f) - 0.1f;
        cam_pitch = (std::max)(-max_pitch, (std::min)(max_pitch, cam_pitch));
    }
}

// 鼠标滚轮回调函数
static void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    // 调整视野大小（灵敏度调整）
    fov -= (float)yoffset * 2.0f;
    
    // 限制视野范围在合理区间
    fov = (std::max)(10.0f, (std::min)(90.0f, fov));
}

// -------------------------- 矩阵工具函数（保持原有） --------------------------
static Mat4 mat4_inverse(const Mat4 &m)
{
    Mat4 inv;
    float a00 = m.m[0], a01 = m.m[1], a02 = m.m[2], a03 = m.m[3];
    float a10 = m.m[4], a11 = m.m[5], a12 = m.m[6], a13 = m.m[7];
    float a20 = m.m[8], a21 = m.m[9], a22 = m.m[10], a23 = m.m[11];
    float a30 = m.m[12], a31 = m.m[13], a32 = m.m[14], a33 = m.m[15];
    inv.m[0] = a11*a22*a33 - a11*a23*a32 - a21*a12*a33 + a21*a13*a32 + a31*a12*a23 - a31*a13*a22;
    inv.m[1] = -a01*a22*a33 + a01*a23*a32 + a21*a02*a33 - a21*a03*a32 - a31*a02*a23 + a31*a03*a22;
    inv.m[2] = a01*a12*a33 - a01*a13*a32 - a11*a02*a33 + a11*a03*a32 + a31*a02*a13 - a31*a03*a12;
    inv.m[3] = -a01*a12*a23 + a01*a13*a22 + a11*a02*a23 - a11*a03*a22 - a21*a02*a13 + a21*a03*a12;
    inv.m[4] = -a10*a22*a33 + a10*a23*a32 + a20*a12*a33 - a20*a13*a32 - a30*a12*a23 + a30*a13*a22;
    inv.m[5] = a00*a22*a33 - a00*a23*a32 - a20*a02*a33 + a20*a03*a32 + a30*a02*a23 - a30*a03*a22;
    inv.m[6] = -a00*a12*a33 + a00*a13*a32 + a10*a02*a33 - a10*a03*a32 - a30*a02*a13 + a30*a03*a12;
    inv.m[7] = a00*a12*a23 - a00*a13*a22 - a10*a02*a23 + a10*a03*a22 + a20*a02*a13 - a20*a03*a12;
    inv.m[8] = a10*a21*a33 - a10*a23*a31 - a20*a11*a33 + a20*a13*a31 + a30*a11*a23 - a30*a13*a21;
    inv.m[9] = -a00*a21*a33 + a00*a23*a31 + a20*a01*a33 - a20*a03*a31 - a30*a01*a23 + a30*a03*a21;
    inv.m[10] = a00*a11*a33 - a00*a13*a31 - a10*a01*a33 + a10*a03*a31 + a30*a01*a13 - a30*a03*a11;
    inv.m[11] = -a00*a11*a23 + a00*a13*a21 + a10*a01*a23 - a10*a03*a21 - a20*a01*a13 + a20*a03*a11;
    inv.m[12] = -a10*a21*a32 + a10*a22*a31 + a20*a11*a32 - a20*a12*a31 - a30*a11*a22 + a30*a12*a21;
    inv.m[13] = a00*a21*a32 - a00*a22*a31 - a20*a01*a32 + a20*a02*a31 + a30*a01*a22 - a30*a02*a21;
    inv.m[14] = -a00*a11*a32 + a00*a12*a31 + a10*a01*a32 - a10*a02*a31 - a30*a01*a12 + a30*a02*a11;
    inv.m[15] = a00*a11*a22 - a00*a12*a21 - a10*a01*a22 + a10*a02*a21 + a20*a01*a12 - a20*a02*a11;
    float det = a00*inv.m[0] + a01*inv.m[4] + a02*inv.m[8] + a03*inv.m[12];
    if (fabsf(det) < 1e-9f) return mat4_identity();
    float invDet = 1.0f / det;
    for (int i=0;i<16;++i) inv.m[i] *= invDet;
    return inv;
}

static void mat4_mul_vec4(const Mat4 &m, float x, float y, float z, float w, float &ox, float &oy, float &oz, float &ow)
{
    ox = m.m[0]*x + m.m[4]*y + m.m[8]*z + m.m[12]*w;
    oy = m.m[1]*x + m.m[5]*y + m.m[9]*z + m.m[13]*w;
    oz = m.m[2]*x + m.m[6]*y + m.m[10]*z + m.m[14]*w;
    ow = m.m[3]*x + m.m[7]*y + m.m[11]*z + m.m[15]*w;
}

static void screen_point_to_ray(int sx, int sy, const Mat4 &view, const Mat4 &proj, int screenW, int screenH, Vec3 &outOrigin, Vec3 &outDir)
{
    float nx = (2.0f * sx) / screenW - 1.0f;
    float ny = 1.0f - (2.0f * sy) / screenH;
    Mat4 mvp = mat4_mul(proj, view);
    Mat4 inv = mat4_inverse(mvp);
    float ox, oy, oz, ow;
    mat4_mul_vec4(inv, nx, ny, -1.0f, 1.0f, ox, oy, oz, ow);
    if (fabsf(ow) > 1e-6f) { ox/=ow; oy/=ow; oz/=ow; }
    Vec3 pnear = {ox, oy, oz};
    mat4_mul_vec4(inv, nx, ny, 1.0f, 1.0f, ox, oy, oz, ow);
    if (fabsf(ow) > 1e-6f) { ox/=ow; oy/=ow; oz/=ow; }
    Vec3 pfar = {ox, oy, oz};
    outOrigin = pnear; outDir = { pfar.x - pnear.x, pfar.y - pnear.y, pfar.z - pnear.z };
    float len = sqrtf(outDir.x*outDir.x + outDir.y*outDir.y + outDir.z*outDir.z); if (len>1e-6f) { outDir.x/=len; outDir.y/=len; outDir.z/=len; }
}

static bool ray_plane_intersect(const Vec3 &ro, const Vec3 &rd, const Vec3 &planeP, const Vec3 &planeN, Vec3 &outP)
{
    float denom = rd.x*planeN.x + rd.y*planeN.y + rd.z*planeN.z;
    if (fabsf(denom) < 1e-6f) return false;
    float t = ((planeP.x - ro.x)*planeN.x + (planeP.y - ro.y)*planeN.y + (planeP.z - ro.z)*planeN.z) / denom;
    if (t < 0) return false;
    outP.x = ro.x + rd.x * t; outP.y = ro.y + rd.y * t; outP.z = ro.z + rd.z * t; return true;
}

static void draw_textured_rect(int x, int y, int w_rect, int h_rect, GLuint tex, const float tint[3], int screenW, int screenH)
{
    float vx[24];
    vx[0] = (float)x; vx[1] = (float)y; vx[2] = 0.0f; vx[3] = 0.0f;
    vx[4] = (float)x; vx[5] = (float)(y+h_rect); vx[6] = 0.0f; vx[7] = 1.0f;
    vx[8] = (float)(x+w_rect); vx[9] = (float)(y+h_rect); vx[10] = 1.0f; vx[11] = 1.0f;
    vx[12] = (float)x; vx[13] = (float)y; vx[14] = 0.0f; vx[15] = 0.0f;
    vx[16] = (float)(x+w_rect); vx[17] = (float)(y+h_rect); vx[18] = 1.0f; vx[19] = 1.0f;
    vx[20] = (float)(x+w_rect); vx[21] = (float)y; vx[22] = 1.0f; vx[23] = 0.0f;
    glBindBuffer(GL_ARRAY_BUFFER, texVBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vx), vx);
    glUseProgram(texProg);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, tex);
    GLint us = glGetUniformLocation(texProg, "uScreen"); glUniform2f(us, (float)screenW, (float)screenH);
    GLint ut = glGetUniformLocation(texProg, "tint"); glUniform3f(ut, tint[0], tint[1], tint[2]);
    glBindVertexArray(texVAO);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glDisable(GL_BLEND);
}

// -------------------------- 主函数（优化字母初始化和绘制） --------------------------
int main()
{
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif
    GLFWwindow* window = glfwCreateWindow(800, 700, "3D Voxel Person - RIGHT CLICK MENU", NULL, NULL);
    if (!window) { std::cout<<"Failed to create window\n"; glfwTerminate(); return -1; }
    glfwMakeContextCurrent(window);
    glfwSetCursorPosCallback(window, cursor_pos_callback);
        glfwSetMouseButtonCallback(window, mouse_button_callback);
        glfwSetScrollCallback(window, scroll_callback);
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) { std::cout<<"Failed to init GLAD\n"; return -1; }
    glEnable(GL_DEPTH_TEST);
    init_gl_resources();

    // GDI+初始化（保持原有）
    GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    // 全局命令行参数（供后续文本/图像路径使用）
    int argc = 0; wchar_t** argvw = CommandLineToArgvW(GetCommandLineW(), &argc);

    // 尝试按原有逻辑从命令行或 portrait.png 生成体素
        wchar_t defaultPath[MAX_PATH];
        GetFullPathNameW(L"portrait.png", MAX_PATH, defaultPath, NULL);
        bool loaded = false;
        if (argc > 1) {
            loaded = load_person_image_and_build_voxels(argvw[1], 32);
        }
        if (!loaded) {
            load_person_image_and_build_voxels(defaultPath, 28);
        }

        wchar_t attachPathW[MAX_PATH];
        GetFullPathNameW(L"attachment.png", MAX_PATH, attachPathW, NULL);
        DWORD attrs = GetFileAttributesW(attachPathW);
        bool usedAttachment = false;
        if (attrs != INVALID_FILE_ATTRIBUTES && !(attrs & FILE_ATTRIBUTE_DIRECTORY)) {
            usedAttachment = build_person_model_from_image(attachPathW, 32);
            if (usedAttachment) std::cout << "Loaded attachment.png and built segmented person model.\n";
        }
        if (!usedAttachment) {
            build_person_from_attachment(); // 使用优化后的人像建模
        }

    // -------------------------- 优化：初始化3D字母（LYBJ） --------------------------
    build_lybj_voxels();   // 初始化LYBJ 3D体素

    // 命令行参数支持（保持原有）
    if (argc > 2) {
        std::wstring wname = argvw[2];
        // build_name_voxels_from_text(wname, 160);
    }
    if (argvw) LocalFree(argvw);

    int winW=800, winH=700; glfwGetWindowSize(window,&winW,&winH);
    double lastTime = glfwGetTime();

    // 主循环（保持原有交互，优化字母绘制）
    while (!glfwWindowShouldClose(window))
    {
        double now = glfwGetTime(); float delta = (float)(now - lastTime); lastTime = now;

        // 输入处理（保持原有）
        if (glfwGetKey(window, GLFW_KEY_ESCAPE)==GLFW_PRESS) glfwSetWindowShouldClose(window, true);

        if (glfwGetKey(window, GLFW_KEY_F5)==GLFW_PRESS) {
            if (!personVariants.empty()) { currentVariant = 0; personVoxels = personVariants[currentVariant]; g_pixel_size = variantPx[currentVariant]; g_depth_size = g_pixel_size * 1.2f; std::cout<<"Switched to variant 0 (W="<<variantWs[0]<<")\n"; }
        }
        if (glfwGetKey(window, GLFW_KEY_F6)==GLFW_PRESS) {
            if (!personVariants.empty() && personVariants.size() > 1) { currentVariant = 1; personVoxels = personVariants[currentVariant]; g_pixel_size = variantPx[currentVariant]; g_depth_size = g_pixel_size * 1.2f; std::cout<<"Switched to variant 1 (W="<<variantWs[1]<<")\n"; }
        }
        if (glfwGetKey(window, GLFW_KEY_F7)==GLFW_PRESS) {
            if (!personVariants.empty() && personVariants.size() > 2) { currentVariant = 2; personVoxels = personVariants[currentVariant]; g_pixel_size = variantPx[currentVariant]; g_depth_size = g_pixel_size * 1.2f; std::cout<<"Switched to variant 2 (W="<<variantWs[2]<<")\n"; }
        }

        // float mv = 1.5f * delta;
        // if (glfwGetKey(window, GLFW_KEY_LEFT)==GLFW_PRESS) letter_off_x -= mv;
        // if (glfwGetKey(window, GLFW_KEY_RIGHT)==GLFW_PRESS) letter_off_x += mv;
        // if (glfwGetKey(window, GLFW_KEY_UP)==GLFW_PRESS) letter_off_z -= mv;
        // if (glfwGetKey(window, GLFW_KEY_DOWN)==GLFW_PRESS) letter_off_z += mv;


        // 渲染准备（保持原有）
        int w,h; glfwGetFramebufferSize(window,&w,&h); glViewport(0,0,w,h);
        glClearColor(0.95f,0.95f,0.95f,1.0f); glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

        // 相机动画（改为鼠标拖拽控制）
        Mat4 proj = mat4_perspective(fov*(3.1415926f/180.0f), (float)w/(float)h, 0.1f, 100.0f);
        float radius = 6.0f;
        
        // 计算相机位置
        float camX = sinf(cam_yaw) * cosf(cam_pitch) * radius;
        float camZ = cosf(cam_yaw) * cosf(cam_pitch) * radius;
        float camY = sinf(cam_pitch) * radius + 1.1f; // 保证相机始终围绕目标高度1.1f旋转
        
        Vec3 eye={camX, camY, camZ}, center={0.0f,1.1f,0.0f}, up={0.0f,1.0f,0.0f};
        Mat4 view = mat4_lookat(eye, center, up);
        g_view = view; g_proj = proj; g_fbW = w; g_fbH = h;

        // 绘制人像：使用程序化体素人像
        float t = (float)glfwGetTime();
        draw_humanoid(t, 0, view, proj);



        // 绘制地面（保持原有）
        draw_block(0.0f, -0.9f, 0.0f, 6.0f, 0.2f, 6.0f, {0.9f,0.9f,0.95f}, view, proj);

        // -------------------------- 优化：绘制LYBJ字母（3D+浮动+旋转+缩放动画） --------------------------
        if (lybj_enabled && !lybjVoxels.empty()) {
            // 绘制白色底板（保持原有）
            float plateW = 1.6f; float plateH = 0.06f; float plateD = 0.9f;
            draw_block(lybj_base_x, lybj_base_y - plateH*0.5f, lybj_base_z, plateW, plateH, plateD, {1.0f,1.0f,1.0f}, view, proj);
            
            // 绘制3D动画字母
            draw_letter_with_anim(
                lybjVoxels, 
                lybj_base_x, lybj_base_y, lybj_base_z,
                lybj_bob_amp, lybj_bob_speed,
                lybj_rot_speed, lybj_scale_amp,
                view, proj
            );
        }

        // 绘制菜单（简化：仅显示一个空白菜单）
        if (menu_open) {
            glDisable(GL_DEPTH_TEST);
            int menu_w = 100; int menu_h = 50;
            int menu_x = (int)menu_pos_x; int menu_y = (int)menu_pos_y;
            if (menu_x + menu_w > w) menu_x = w - menu_w - 4;
            if (menu_y + menu_h > h) menu_y = h - menu_h - 4;
            float whiteTint[3] = {1.0f,1.0f,1.0f};
            draw_textured_rect(menu_x, menu_y, menu_w, menu_h, whiteTex, whiteTint, w, h);
            glEnable(GL_DEPTH_TEST);
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // 资源释放（保持原有）
    glfwTerminate();
    GdiplusShutdown(gdiplusToken);
    return 0;
}